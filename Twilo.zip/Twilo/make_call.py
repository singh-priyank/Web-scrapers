# Download the helper library from https://www.twilio.com/docs/python/install
def call_number():
    import os
    from twilio.rest import Client

    # Find your Account SID and Auth Token at twilio.com/console
    # and set the environment variables. See http://twil.io/secure
    account_sid = "ACf00886a0ed9e0cf1720383f26175deb7"
    auth_token = "1e43dd489d35e5b24ebb8ea6d1130c68"
    client = Client(account_sid, auth_token)

    call = client.calls.create(
        url="https://6765-2405-201-681b-20f9-d5b6-e63a-7163-4091.ngrok-free.app/voice",
        to="+13344543988",
        from_="+13344543988",
    )

    print(call.sid)

call_number()