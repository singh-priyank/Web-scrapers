from time import sleep
from flask import Flask, request, jsonify
from twilio.twiml.messaging_response import MessagingResponse
from twilio.twiml.voice_response import VoiceResponse, Say

app = Flask(__name__)

# Method to send response to the dialogflow
@app.route('/gdf', methods=['GET', 'POST'])
def gdf():
    req = request.get_json(silent=True, force=True)
    print(req)
    response = {
        'fulfillment_response': {
            'messages': [
                {
                    'text': {
                        'text': ['''Thank you. I see your mobile number that you are calling is associated with the account number and Your current balance is 
                One Lakh Fifty thousand and five Rupees and thirty five Paisa. Is there anything else?'''],
                    },
                },
            ],
        },
    }
    # sleep(1)
    # Call number will call to a the bank number, need to fix this with account upgrade
    # call_number()
    return jsonify(response)


@app.route('/sms', methods=['POST'])
def sms():
    print(request.form)
    number = request.form['From']
    message_body = request.form['Body']

    resp = MessagingResponse()
    resp.message('Hello {}, you said: {}'.format(number, message_body))
    
    return str(resp)


@app.route("/voice", methods=['POST'])
def voice():
    response = VoiceResponse()
    say = Say('Hi Welcome to our bank', voice='Polly.Emma')
    say.break_(strength='x-weak', time='1000ms')
    # say.p('Welcome to the our Bank.')
    # say.break_(strength='x-weak', time='50ms')

    response.append(say)
    response.play(digits='1')

    sleep(1)
    response.hangup()

    return str(response)


@app.route('/')
def index():
    return """ Hi this is my bank
    """

def call_number():
    import os
    from twilio.rest import Client

    # Find your Account SID and Auth Token at twilio.com/console
    # and set the environment variables. See http://twil.io/secure
    account_sid = "ACf00886a0ed9e0cf1720383f26175deb7"
    auth_token = "1e43dd489d35e5b24ebb8ea6d1130c68"
    client = Client(account_sid, auth_token)

    call = client.calls.create(
        url="https://6765-2405-201-681b-20f9-d5b6-e63a-7163-4091.ngrok-free.app/voice",
        to="-----------",
        from_="+13344543988",
    )

    print(call.sid)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000)